
$(document).ready(function(){

  $('#mobile-menu-active').meanmenu({
      meanScreenWidth:"991",
      meanMenuContainer:".mobile-menu"
  });

  // slider active
  $('.slider-active').slick({
      infinite:true,
      slidesToShow:1,
      arrows:false,
      dots:false,
      autopaly:true,
      slidesToScroll:1

  });
    
  // testmonial active

  $('.testmonial-active').slick({
      infinite:true,
      slidesToShow:1,
      arrows:false,
      dots:true,
      autopaly:true,
      slidesToScroll:1

  });
  // brand active

  $('.brand-active').slick({
      infinite:true,
      slidesToShow:5,
      arrows:false,
      dots:false,
      autopaly:true,
      slidesToScroll:1,
      responsive: [{
          breakpoint: 1024,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
            infinite: true,
            dots: false,
          }
        },
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 2
  

          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]

  });


  // WOW active
  new WOW().init();
    
  //  Counter Plagin
  $('.counter').counterUp({
    delay: 10,
    time: 1000
  });

  // scrollToTop
  $.scrollUp({
    scrollName: 'scrollUp', // Element ID
    topDistance: '300', // Distance from top before showing element (px)
    topSpeed: 300, // Speed back to top (ms)
    animation: 'fade', // Fade, slide, none
    animationInSpeed: 200, // Animation in speed (ms)
    animationOutSpeed: 200, // Animation out speed (ms)
    scrollText: '<i class="fas fa-angle-up"></i>', // Text for element
    activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
  });

    


})

